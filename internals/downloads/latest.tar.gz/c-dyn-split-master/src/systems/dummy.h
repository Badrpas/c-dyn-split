
#define LUL "> [kek]"

void hosted2();

